"""Implementacao de CloudProvider para AWS, apoiada em um ComputeProvider.

Esta classe traduz o contrato de alto nivel `CloudProvider` para o contrato
de execucao `ComputeProvider`. Nenhuma logica de dominio depende desta
classe diretamente - ela e resolvida exclusivamente pela ProviderFactory.
"""
from __future__ import annotations

from app.domain.contracts.cloud_provider import CloudProvider
from app.domain.contracts.compute_provider import ComputeProvider
from app.domain.models.deployment import Deployment, HealthCheckResult
from app.domain.models.microservice import MicroserviceConfig
from app.domain.models.migration import WorkloadReference
from app.domain.models.provider import ProviderConfig


class AWSProvider(CloudProvider):
    """Provedor de nuvem AWS (compativel com o emulador Floci).

    Delegando a criacao/remocao/health-check do workload para um
    ComputeProvider concreto (ex: DockerComputeProvider), mantendo este
    provider agnostico ao mecanismo exato de execucao.
    """

    def __init__(self, config: ProviderConfig, compute_provider: ComputeProvider) -> None:
        self._config = config
        self._compute_provider = compute_provider

    def deploy_service(self, config: MicroserviceConfig) -> Deployment:
        return self._compute_provider.deploy(config.container)

    def remove_service(self, deployment: Deployment) -> None:
        self._compute_provider.remove(deployment)

    def get_service_endpoint(self, deployment: Deployment) -> str:
        return self._compute_provider.get_endpoint(deployment)

    def health_check(self, deployment: Deployment) -> HealthCheckResult:
        return self._compute_provider.health_check(deployment)

    def discover_service(self, reference: WorkloadReference) -> Deployment:
        return self._compute_provider.discover(reference)

    def start_service(self, deployment: Deployment) -> None:
        self._compute_provider.start(deployment)

    def stop_service(self, deployment: Deployment) -> None:
        self._compute_provider.stop(deployment)
